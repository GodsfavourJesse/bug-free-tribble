import {
    boolean,
    jsonb,
    pgEnum,
    pgTable,
    timestamp,
    uniqueIndex,
    uuid,
    varchar,
} from "drizzle-orm/pg-core";

import { users } from "../users/users.ts";

// Every notification is stored so the user can read it later,
// even when they are offline.
export const notificationTypeEnum = pgEnum(
    "notification_type",
    [
        "GENERAL",
        "LISTING_SUBMITTED",
        "LISTING_APPROVED",
        "LISTING_REJECTED",
        "LISTING_EXPIRED",
        "LISTING_SOLD",

        "SUBSCRIPTION_PAYMENT_PENDING",
        "SUBSCRIPTION_ACTIVATED",
        "SUBSCRIPTION_EXPIRED",
        "SUBSCRIPTION_EXPIRY_REMINDER",

        "BOOST_PAYMENT_PENDING",
        "BOOST_PAYMENT_SUCCESSFUL",
        "BOOST_PAYMENT_RECEIVED",
        "BOOST_ACTIVATED",
        "BOOST_EXPIRY_REMINDER",
        "BOOST_EXPIRED",

        "MESSAGE_RECEIVED",
        "DEALER_VERIFIED",
        "DEALER_APPLICATION_REJECTED",
    ],
);

export const notifications = pgTable(
    "notifications",
    {
        id: uuid("id")
            .defaultRandom()
            .primaryKey(),

        userId: uuid("user_id")
            .notNull()
            .references(() => users.id, {
                onDelete: "cascade",
            }),

        type: notificationTypeEnum("type")
            .notNull()
            .default("GENERAL"),

        title: varchar("title", {
            length: 200,
        }).notNull(),

        message: varchar("message", {
            length: 1000,
        }).notNull(),

        data: jsonb("data"),

        idempotencyKey: varchar("idempotency_key", {
            length: 255,
        }),

        read: boolean("read")
            .notNull()
            .default(false),

        readAt: timestamp("read_at", {
            withTimezone: true,
        }),

        createdAt: timestamp("created_at", {
            withTimezone: true,
        })
            .notNull()
            .defaultNow(),
    },
    (table) => ({
        idempotencyKeyUnique: uniqueIndex(
            "notifications_idempotency_key_unique",
        ).on(table.idempotencyKey),
    }),
);

export const notificationPreferences = pgTable(
    "notification_preferences",
    {
        id: uuid("id")
            .defaultRandom()
            .primaryKey(),

        userId: uuid("user_id")
            .notNull()
            .unique()
            .references(() => users.id, {
                onDelete: "cascade",
            }),

        inAppEnabled: boolean("in_app_enabled")
            .notNull()
            .default(true),

        emailEnabled: boolean("email_enabled")
            .notNull()
            .default(true),

        createdAt: timestamp("created_at", {
            withTimezone: true,
        })
            .notNull()
            .defaultNow(),

        updatedAt: timestamp("updated_at", {
            withTimezone: true,
        })
            .notNull()
            .defaultNow(),
    },
);