import {
    and,
    count,
    desc,
    eq,
    gt,
    ilike,
    isNull,
    inArray,
    ne,
    or,
    sql,
    type SQL,
} from "drizzle-orm";

import { logger } from "../../../config/logger.ts";

import { env } from "../../../config/env.ts";

import { db } from "../../../database/index.ts";

import {
    idempotencyRecords,
    imageAnalysisJobs,
    listingHistory,
    listingImages,
    listings,
    vehicleGenerations,
    vehicleMakes,
    vehicleModels,
    vehicleVariants,
    roles,
    userRoles,
    users,
} from "../../../database/schema/index.ts";

import {
    createObjectKey,
    getObjectStorage,
} from "../../../infrastructure/storage/object-storage.ts";

import { 
    type ListingDetailsUpdate, 
    transitionListing 
} from "./listing.lifecycle.ts";

import {
    type GetListingViewer,
    type SellerListingsOptions,
    type SellerListingStatus,
    type ListingVehicleDetails,
} from "./listing.types.ts";

import {
    createAnonymousViewerKey,
    createAuthenticatedViewerKey,
    recordListingView,
} from "../listing-view/listing-view.service.ts";
import { normalizeImage } from "../../../infrastructure/storage/image-normalizer.ts";
import { validateImage } from "../../../infrastructure/storage/image-validator.ts";
import { 
    consumeCreditUsingExecutor, 
    CREDIT_REASONS,
    type CreditConsumptionResult, 
} from "../../credits/credit.service.ts";
import { AppError } from "../../../errors/app-error.ts";
import { createHash } from "node:crypto";
import { enqueueImageAnalysisJob } from "../../image-module/image-analysis/image-analysis-job.service.ts";
import { createNotification } from "../../notification-module/notification.service.ts";

const CREATE_LISTING_OPERATION = "CREATE_LISTING";

const IDEMPOTENCY_KEY_TTL_HOURS = 24;

interface CreateListingResult {
    listing: typeof listings.$inferSelect;
    replayed: boolean;
    creditConsumption: CreditConsumptionResult | null;
}

interface IdempotencyResponseBody
    extends Record<string, unknown> {
    success: true;

    data: {
        listing: typeof listings.$inferSelect;

        /**
         * Persisted alongside the original listing response.
         * Optional for compatibility with older idempotency records.
         */
        creditConsumption?: CreditConsumptionResult;
    };
}

interface CreateListingInput extends ListingVehicleDetails {
    sellerId: string;
    title: string;
    description: string;
    price: number;
    currency: string;
    mileage?: number;

    condition:
        | "BRAND_NEW"
        | "FOREIGN_USED"
        | "NIGERIAN_USED";

    country: string;
    state?: string;
    city?: string;
}

/*
 * ============================================================
 * LISTING CREATION ENTITLEMENT
 * ============================================================
 *
 * Business rules:
 *
 * 1. Free-trial credits do not expire.
 * 2. Subscription credits carry forward indefinitely.
 * 3. Once the free-trial allowance is exhausted, a valid
 *    paid entitlement is required to create new listings.
 * 4. A cancelled subscription retains entitlement until its
 *    recorded expiration date.
 * 5. Credit balance is checked separately by the centralized
 *    credit service.
 */

type DatabaseTransaction = Parameters<
    Parameters<typeof db.transaction>[0]
>[0];

type DatabaseExecutor =
    | typeof db
    | DatabaseTransaction;

async function getSellerListingImageSummaries(
    listingIds: string[],
) {
    type SellerImageSummary = {
        total: number;
        pending: number;
        passed: number;
        review: number;
        failed: number;
        images: {
            id: string;
            sortOrder: number;
            imageCheckStatus: string;
            imageCheckSource: string | null;
            checkReason: string | null;
            checkedAt: Date | null;
            url: string;
            thumbnailUrl: string;
            canRetry: boolean;
        }[];
    };

    if (listingIds.length === 0) {
        return new Map<string, SellerImageSummary>();
    }

    const images = await db
        .select({
            id: listingImages.id,
            listingId: listingImages.listingId,
            objectKey: listingImages.objectKey,
            sortOrder: listingImages.sortOrder,
            imageCheckStatus: listingImages.imageCheckStatus,
            imageCheckSource: listingImages.imageCheckSource,
            checkReason: listingImages.checkReason,
            checkedAt: listingImages.checkedAt,
        })
        .from(listingImages)
        .where(
            sql`${listingImages.listingId} IN (${sql.join(
                listingIds.map((id) => sql`${id}`),
                sql`, `,
            )})`,
        )
        .orderBy(
            listingImages.sortOrder,
        );

    const storage = getObjectStorage();

    const summaries = new Map<string, SellerImageSummary>();

    for (const image of images) {
        let summary = summaries.get(image.listingId);

        if (!summary) {
            summary = {
                total: 0,
                pending: 0,
                passed: 0,
                review: 0,
                failed: 0,
                images: [],
            };

            summaries.set(image.listingId, summary);
        }

        summary.total += 1;

        switch (image.imageCheckStatus) {
            case "PENDING":
                summary.pending += 1;
                break;

            case "PASSED":
                summary.passed += 1;
                break;

            case "REVIEW":
                summary.review += 1;
                break;

            case "FAILED":
                summary.failed += 1;
                break;
        }

        summary.images.push({
            id: image.id,
            sortOrder: image.sortOrder,
            imageCheckStatus: image.imageCheckStatus,
            imageCheckSource: image.imageCheckSource,
            checkReason: image.checkReason,
            checkedAt: image.checkedAt,

            url: storage.publicUrl(
                image.objectKey,
                {
                    resourceType: "image",
                    access: "public",
                },
            ),

            thumbnailUrl: storage.transformedImageUrl(
                image.objectKey,
                {
                    width: 600,
                    height: 600,
                    fit: "fit",
                    quality: "auto",
                    format: "webp",
                },
            ),

            canRetry:
                image.imageCheckStatus === "FAILED" &&
                image.imageCheckSource === "AUTOMATED",
        });
    }

    return summaries;
}

export async function createListing(
    input: CreateListingInput,
    idempotencyKey: string,
): Promise<CreateListingResult> {
    const normalizedKey = idempotencyKey.trim();

    if (
        normalizedKey.length === 0 ||
        normalizedKey.length > 255
    ) {
        throw new AppError(
            "A valid Idempotency-Key header is required.",
            400,
            "INVALID_IDEMPOTENCY_KEY",
        );
    }

    const canonicalPayload = JSON.stringify({
        ...input,
        title: input.title,
        description: input.description,
        price: input.price,
        currency: input.currency,
        mileage: input.mileage ?? null,
        condition: input.condition,
        country: input.country,
        state: input.state ?? null,
        city: input.city ?? null,
    });

    const payloadHash = createHash("sha256")
        .update(canonicalPayload)
        .digest("hex");

    /*
     * Everything required to create the listing and consume
     * its credit is committed in one transaction.
     */
    const result = await db.transaction(async (tx) => {
        const now = new Date();

        await tx
            .delete(idempotencyRecords)
            .where(
                and(
                    eq(idempotencyRecords.userId, input.sellerId),
                    eq(
                        idempotencyRecords.operation,
                        CREATE_LISTING_OPERATION,
                    ),
                    eq(idempotencyRecords.key, normalizedKey),
                    sql`${idempotencyRecords.expiresAt} <= ${now}`,
                ),
            );

        const claimed = await tx
            .insert(idempotencyRecords)
            .values({
                userId: input.sellerId,
                operation: CREATE_LISTING_OPERATION,
                key: normalizedKey,
                payloadHash,
                expiresAt: new Date(
                    now.getTime() +
                        IDEMPOTENCY_KEY_TTL_HOURS *
                            60 *
                            60 *
                            1000,
                ),
            })
            .onConflictDoNothing({
                target: [
                    idempotencyRecords.userId,
                    idempotencyRecords.operation,
                    idempotencyRecords.key,
                ],
            })
            .returning({
                id: idempotencyRecords.id,
            });

        /*
         * Handle an existing idempotency key.
         */
        if (claimed.length === 0) {
            const existingRows = await tx
                .select()
                .from(idempotencyRecords)
                .where(
                    and(
                        eq(
                            idempotencyRecords.userId,
                            input.sellerId,
                        ),
                        eq(
                            idempotencyRecords.operation,
                            CREATE_LISTING_OPERATION,
                        ),
                        eq(
                            idempotencyRecords.key,
                            normalizedKey,
                        ),
                    ),
                )
                .limit(1);

            const existing = existingRows[0];

            if (!existing) {
                throw new AppError(
                    "Unable to resolve the idempotency key. Please retry with a new key.",
                    409,
                    "IDEMPOTENCY_CONFLICT",
                );
            }

            if (existing.payloadHash !== payloadHash) {
                throw new AppError(
                    "This Idempotency-Key has already been used with a different listing payload.",
                    409,
                    "IDEMPOTENCY_KEY_REUSED",
                );
            }

            if (
                existing.responseBody === null ||
                existing.responseBody === undefined
            ) {
                throw new AppError(
                    "The original request result is unavailable. Please retry with a new Idempotency-Key.",
                    409,
                    "IDEMPOTENCY_RESULT_UNAVAILABLE",
                );
            }

            const responseBody =
                existing.responseBody as unknown as IdempotencyResponseBody;

            return {
                listing: responseBody.data.listing,
                creditConsumption:
                    responseBody.data.creditConsumption ?? null,
                replayed: true,
            };
        }

        /*
         * Serialize credit operations for this user.
         */
        await tx.execute(sql`
            SELECT pg_advisory_xact_lock(
                hashtext(
                    ${`karmass:listing-credit:${input.sellerId}`}
                )
            )
        `);

        if (input.vehicleVariantId) {
            const variant = await tx
                .select({ id: vehicleVariants.id })
                .from(vehicleVariants)
                .where(eq(vehicleVariants.id, input.vehicleVariantId))
                .limit(1);

            if (!variant[0]) {
                throw new AppError(
                    "Vehicle variant not found.",
                    404,
                    "VEHICLE_VARIANT_NOT_FOUND",
                );
            }
        }

        const inserted = await tx
            .insert(listings)
            .values({
                sellerId: input.sellerId,
                vehicleVariantId: input.vehicleVariantId ?? null,
                makeName: input.makeName ?? null,
                modelName: input.modelName ?? null,
                year: input.year ?? null,
                generationName: input.generationName || null,
                variantName: input.variantName || null,
                bodyStyle: input.bodyStyle || null,
                fuelType: input.fuelType || null,
                transmission: input.transmission || null,
                driveType: input.driveType || null,
                engineCapacity: input.engineCapacity || null,
                horsepower: input.horsepower ?? null,
                exteriorColor: input.exteriorColor || null,
                interiorColor: input.interiorColor || null,
                seats: input.seats ?? null,
                doors: input.doors ?? null,
                specifications: input.specifications ?? {},
                title: input.title,
                description: input.description,
                price: input.price.toString(),
                currency: input.currency,
                ...(input.mileage !== undefined
                    ? { mileage: input.mileage }
                    : {}),
                condition: input.condition,
                country: input.country,
                ...(input.state !== undefined
                    ? { state: input.state }
                    : {}),
                ...(input.city !== undefined
                    ? { city: input.city }
                    : {}),
                status: "DRAFT",
            })
            .returning();

        const listing = inserted[0];

        if (!listing) {
            throw new AppError(
                "Failed to create listing.",
                500,
                "LISTING_CREATE_FAILED",
            );
        }

        /*
         * Consume the appropriate credit.
         *
         * Subscription credits are consumed first,
         * followed by free credits.
         */
        const creditConsumption =
            await consumeCreditUsingExecutor(tx, {
                userId: input.sellerId,
                reason: CREDIT_REASONS.LISTING_CREATED,
                referenceId: listing.id,
            });

        await tx
            .insert(listingHistory)
            .values({
                listingId: listing.id,
                actorId: input.sellerId,
                action: "CREATED",
                previousStatus: null,
                newStatus: "DRAFT",
                reason: "Listing created.",
            });

        /*
         * Persist the complete response, including the
         * credit-consumption event.
         *
         * This allows safe notification retries when the
         * same idempotency key is replayed.
         */
        const responseBody: IdempotencyResponseBody = {
            success: true,
            data: {
                listing,
                creditConsumption,
            },
        };

        await tx
            .update(idempotencyRecords)
            .set({
                listingId: listing.id,
                responseStatus: 201,
                responseBody,
            })
            .where(
                eq(
                    idempotencyRecords.id,
                    claimed[0]!.id,
                ),
            );

        return {
            listing,
            creditConsumption,
            replayed: false,
        };
    });

    /*
     * IMPORTANT:
     *
     * Notifications are created AFTER the listing transaction
     * commits. A notification failure must never roll back
     * a successfully created listing.
     *
     * The idempotency key prevents duplicate notifications.
     */
    if (
        result.creditConsumption?.subscriptionCreditsExhausted
    ) {
        const freeCreditsRemaining =
            result.creditConsumption.freeCreditsRemaining;

        const hasFreeCredits =
            freeCreditsRemaining > 0;

        try {
            await createNotification({
                userId: input.sellerId,

                type: "SUBSCRIPTION_CREDITS_EXHAUSTED",

                title: "Your subscription listing credits are exhausted",

                message: hasFreeCredits
                    ? `You've used the last listing credit from your subscription. You still have ${freeCreditsRemaining} free listing credit${freeCreditsRemaining === 1 ? "" : "s"}. Your next listing will use your remaining free credits.`
                    : "You've used the last listing credit from your subscription and have no free listing credits remaining. Purchase another plan to create more listings.",

                data: {
                    event: "SUBSCRIPTION_CREDITS_EXHAUSTED",
                    listingId: result.listing.id,

                    subscriptionCreditsRemaining:
                        result.creditConsumption.subscriptionCreditsRemaining,

                    freeCreditsRemaining,

                    adjustmentCreditsRemaining:
                        result.creditConsumption.adjustmentCreditsRemaining,

                    totalRemaining:
                        result.creditConsumption.remaining,

                    hasFreeCredits,

                    buyPlanRequired: !hasFreeCredits,
                },

                idempotencykey:
                    `subscription-credits-exhausted:${input.sellerId}:${result.listing.id}`,
            });
        } catch (error) {
            logger.error(
                {
                    err: error,
                    userId: input.sellerId,
                    listingId: result.listing.id,
                },
                "Listing creation succeeded, but subscription-credit exhaustion notification could not be created.",
            );
        }
    }

    return result;
}

export async function getListingById(
    listingId: string,
    viewer?: GetListingViewer,
) {
    const result = await db
        .select({
            listing: listings,
            variant:
                vehicleVariants,
            generation:
                vehicleGenerations,
            model:
                vehicleModels,
            make:
                vehicleMakes,
        })
        .from(listings)
        .leftJoin(
            vehicleVariants,
            eq(
                listings.vehicleVariantId,
                vehicleVariants.id,
            ),
        )
        .leftJoin(
            vehicleGenerations,
            eq(
                vehicleVariants.generationId,
                vehicleGenerations.id,
            ),
        )
        .leftJoin(
            vehicleModels,
            eq(
                vehicleGenerations.modelId,
                vehicleModels.id,
            ),
        )
        .leftJoin(
            vehicleMakes,
            eq(
                vehicleModels.makeId,
                vehicleMakes.id,
            ),
        )
        .where(
            eq(
                listings.id,
                listingId,
            ),
        )
        .limit(1);

    const record =
        result[0];

    if (!record) {
        return null;
    }

    const images =
        await db
            .select()
            .from(listingImages)
            .where(
                eq(
                    listingImages.listingId,
                    listingId,
                ),
            )
            .orderBy(
                listingImages.sortOrder,
            );

    const storage =
        getObjectStorage();

    const imagesWithUrls =
        images.map((image) => ({
            ...image,

            url:
                storage.publicUrl(
                    image.objectKey,
                    {
                        resourceType:
                            "image",

                        access:
                            "public",
                    },
                ),

            thumbnailUrl:
                storage.transformedImageUrl(
                    image.objectKey,
                    {
                        width: 600,
                        height: 600,
                        fit: "fit",
                        quality: "auto",
                        format: "webp",
                    },
                ),

            detailUrl:
                storage.transformedImageUrl(
                    image.objectKey,
                    {
                        width: 1600,
                        height: 1600,
                        fit: "limit",
                        quality: "auto",
                        format: "webp",
                    },
                ),
        }));

    /*
     * View tracking is intentionally best-effort.
     *
     * A failure in the analytics/view system must never
     * prevent a valid listing from being returned to the user.
     */
    try {
        if (viewer?.userId) {
            await recordListingView({
                listingId,

                viewerId:
                    viewer.userId,

                viewerKey:
                    createAuthenticatedViewerKey(
                        viewer.userId,
                    ),
            });
        } else if (
            viewer?.visitorId
        ) {
            await recordListingView({
                listingId,

                viewerKey:
                    createAnonymousViewerKey(
                        viewer.visitorId,
                    ),
            });
        }
    } catch (error) {
        logger.error(
            {
                err: error,
                listingId,
            },
            "Failed to record listing view.",
        );
    }

    return {
        ...record,

        images:
            imagesWithUrls,
    };
}

export async function updateListing(
    listingId: string,
    sellerId: string,
    input: Partial<CreateListingInput>,
) {
    /*
     * 1. Verify listing ownership.
     */
    const result = await db
        .select()
        .from(listings)
        .where(
            and(
                eq(listings.id, listingId),
                eq(listings.sellerId, sellerId),
            ),
        )
        .limit(1);

    const listing = result[0];

    if (!listing) {
        throw new AppError(
            "Listing not found or you do not have permission to update it.",
            404,
            "LISTING_NOT_FOUND",
        );
    }

    /*
     * 2. Validate a replacement vehicle variant.
     */
    if (
        input.vehicleVariantId !== undefined &&
        input.vehicleVariantId !== null
    ) {
        const variant = await db
            .select({
                id: vehicleVariants.id,
            })
            .from(vehicleVariants)
            .where(
                eq(
                    vehicleVariants.id,
                    input.vehicleVariantId,
                ),
            )
            .limit(1);

        if (!variant[0]) {
            throw new AppError(
                "The selected vehicle variant does not exist.",
                400,
                "INVALID_VEHICLE_VARIANT",
            );
        }
    }

    /*
     * 3. Build the details object.
     *
     * Omitted properties remain unchanged.
     */
    const details: ListingDetailsUpdate = {};

    if (input.vehicleVariantId !== undefined) {
        details.vehicleVariantId =
            input.vehicleVariantId;
    }

    const vehicleFields = [
        "makeName", "modelName", "year", "generationName", "variantName",
        "bodyStyle", "fuelType", "transmission", "driveType", "engineCapacity",
        "horsepower", "exteriorColor", "interiorColor", "seats", "doors",
        "specifications",
    ] as const;

    for (const field of vehicleFields) {
        const value = input[field];
        if (value !== undefined) {
            Object.assign(details, { [field]: value });
        }
    }

    if (input.title !== undefined) {
        details.title = input.title;
    }

    if (input.description !== undefined) {
        details.description = input.description;
    }

    if (input.price !== undefined) {
        details.price = input.price;
    }

    if (input.currency !== undefined) {
        details.currency = input.currency;
    }

    if (input.mileage !== undefined) {
        details.mileage = input.mileage;
    }

    if (input.condition !== undefined) {
        details.condition = input.condition;
    }

    if (input.country !== undefined) {
        details.country = input.country;
    }

    if (input.state !== undefined) {
        details.state = input.state;
    }

    if (input.city !== undefined) {
        details.city = input.city;
    }

    /*
     * 4. Reject empty updates.
     */
    if (Object.keys(details).length === 0) {
        throw new AppError(
            "Provide at least one listing field to update.",
            400,
            "EMPTY_LISTING_UPDATE",
        );
    }

    /*
     * 5. Apply the update through the lifecycle service.
     *
     * This ensures that:
     * - The lifecycle transition is validated.
     * - The listing status is updated appropriately.
     * - Listing history is recorded transactionally.
     */
    return transitionListing({
        listingId,
        actorId: sellerId,
        action: "UPDATE_DETAILS",
        details,
        reason: "Listing details updated by seller.",
    });
}

export async function deleteListing(
    listingId: string,
    sellerId: string,
) {
    /*
     * 1. Verify that the listing exists
     *    and belongs to the requesting seller.
     */
    const result = await db
        .select({
            id: listings.id,
        })
        .from(listings)
        .where(
            and(
                eq(listings.id, listingId),
                eq(listings.sellerId, sellerId),
            ),
        )
        .limit(1);

    if (!result[0]) {
        throw new AppError(
            "Listing not found or you do not have permission to delete it.",
            404,
            "LISTING_NOT_FOUND",
        );
    }

    /*
     * 2. Delete through the lifecycle service.
     *
     * The lifecycle service validates whether deletion
     * is allowed for the listing's current status.
     *
     * It also updates the status and records the action
     * in listingHistory within the same transaction.
     */
    return transitionListing({
        listingId,
        actorId: sellerId,
        action: "DELETE",
        reason: "Listing deleted by seller.",
    });
}

export async function addListingImage(
    listingId: string,
    sellerId: string,
    input: {
    file: Express.Multer.File;
    sortOrder: number;
    },
) {
    const storage = getObjectStorage();

    /*
    * Track the uploaded object so that if the database
    * transaction fails, we can clean up the orphaned object.
    */
    let uploadedObjectKey: string | undefined;

    try {
        const image = await db.transaction(async (tx) => {
            /*
            * Serialize image uploads for this listing.
            *
            * This protects the maximum-image-count check
            * against concurrent uploads.
            */
            await tx.execute(
                sql`SELECT pg_advisory_xact_lock(hashtext(${listingId}))`,
            );

            /*
            * Verify listing ownership.
            */
            const listing = await tx
                .select({
                    id: listings.id,
                })
                .from(listings)
                .where(
                    and(
                        eq(listings.id, listingId),
                        eq(listings.sellerId, sellerId),
                    ),
                )
                .limit(1);

            if (!listing[0]) {
                throw new AppError(
                    "Listing not found or you do not have permission to upload images.",
                    404,
                    "LISTING_NOT_FOUND",
                );
            }

            /*
            * Enforce the maximum number of images.
            */
            const imageCountResult = await tx
                .select({
                    count: count(),
                })
                .from(listingImages)
                .where(
                    eq(
                        listingImages.listingId,
                        listingId,
                    ),
                );

            const imageCount = Number(
                imageCountResult[0]?.count ?? 0,
            );

            if (imageCount >= env.MAX_IMAGES_PER_LISTING) {
                throw new AppError(
                    `Maximum of ${env.MAX_IMAGES_PER_LISTING} images allowed per listing.`,
                    400,
                    "MAX_LISTING_IMAGES_EXCEEDED",
                );
            }

            /*
            * Validate the actual image contents.
            *
            * Do not trust the browser-provided MIME type.
            */
            await validateImage(input.file.buffer);

            /*
            * Normalize the image to WebP.
            */
            const normalized = await normalizeImage(
                input.file.buffer,
            );

            /*
            * Store the normalized image.
            */
            const requestedObjectKey = createObjectKey(
                `listings/${listingId}`,
                "webp",
            );

            const storedObject = await storage.put(
                requestedObjectKey,
                normalized.buffer,
                "image/webp",
                {
                    resourceType: "image",
                    access: "public",
                    format: "webp",
                },
            );

            const objectKey = storedObject.key;

            uploadedObjectKey = objectKey;

            /*
            * Insert the image and its durable analysis job
            * inside the same database transaction.
            *
            * If either database insertion fails, the
            * transaction rolls back both records.
            */
            const insertedImages = await tx
                .insert(listingImages)
                .values({
                    listingId,
                    objectKey,
                    sortOrder: input.sortOrder,
                    imageCheckStatus: "PENDING",
                    mimeType: "image/webp",
                    width: normalized.width,
                    height: normalized.height,
                    ...(input.file.originalname
                        ? {
                            originalName:
                                input.file.originalname,
                        }
                        : {}),
                })
                .returning();

            const insertedImage = insertedImages[0];

            if (!insertedImage) {
                throw new AppError(
                    "Unable to create listing image.",
                    500,
                    "LISTING_IMAGE_CREATE_FAILED",
                );
            }

            /*
            * Queue image analysis automatically.
            *
            * Database defaults should initialize the job's
            * status, attempts, priority, and availability.
            */
            await tx
                .insert(imageAnalysisJobs)
                .values({
                    listingImageId: insertedImage.id,
                });

            return insertedImage;
        });

        /*
        * The database transaction has committed successfully.
        *
        * The background worker now owns image analysis.
        * Do not call analyzeImage() here.
        */
        return image;
    } catch (error) {
        /*
        * If storage succeeded but the database transaction
        * failed, clean up the stored object.
        */
        if (uploadedObjectKey !== undefined) {
            try {
                await storage.delete(
                    uploadedObjectKey,
                    {
                        resourceType: "image",
                    },
                );

                uploadedObjectKey = undefined;
            } catch (cleanupError) {
                logger.error(
                    {
                        err: cleanupError,
                        listingId,
                        objectKey: uploadedObjectKey,
                    },
                    "Failed to clean up orphaned listing image.",
                );
            }
        }

        throw error;
    }
}


export async function searchListings(
    search?: string,
) {
    const now =
        new Date();

    const conditions: SQL[] = [
        eq(
            listings.status,
            "APPROVED",
        ),
    ];

    const visibilityCondition =
        or(
            isNull(
                listings.expiresAt,
            ),
            gt(
                listings.expiresAt,
                now,
            ),
        );

    if (
        visibilityCondition
    ) {
        conditions.push(
            visibilityCondition,
        );
    }

    if (search) {
        const pattern =
            `%${search}%`;

        const searchCondition =
            or(
                ilike(
                    listings.title,
                    pattern,
                ),

                ilike(
                    listings.description,
                    pattern,
                ),

                ilike(
                    vehicleVariants.name,
                    pattern,
                ),

                ilike(
                    vehicleModels.name,
                    pattern,
                ),

                ilike(vehicleMakes.name, pattern),
                ilike(listings.makeName, pattern),
                ilike(listings.modelName, pattern),
                ilike(listings.generationName, pattern),
                ilike(listings.variantName, pattern),
            );

        if (
            searchCondition
        ) {
            conditions.push(
                searchCondition,
            );
        }
    }

    return db
        .select({
            listing: listings,

            variant:
                vehicleVariants,

            generation:
                vehicleGenerations,

            model:
                vehicleModels,

            make:
                vehicleMakes,
        })
        .from(listings)
        .leftJoin(
            vehicleVariants,
            eq(
                listings.vehicleVariantId,
                vehicleVariants.id,
            ),
        )
        .leftJoin(
            vehicleGenerations,
            eq(
                vehicleVariants.generationId,
                vehicleGenerations.id,
            ),
        )
        .leftJoin(
            vehicleModels,
            eq(
                vehicleGenerations.modelId,
                vehicleModels.id,
            ),
        )
        .leftJoin(
            vehicleMakes,
            eq(
                vehicleModels.makeId,
                vehicleMakes.id,
            ),
        )
        .where(
            and(...conditions),
        )
        .orderBy(
            desc(
                listings.createdAt,
            ),
        )
        .limit(50);
}

export async function submitListingForReview(
    listingId: string,
    sellerId: string,
) {
    const listingResult = await db
        .select({
            id: listings.id,
            sellerId: listings.sellerId,
            status: listings.status,
        })
        .from(listings)
        .where(eq(listings.id, listingId))
        .limit(1);

    const listing = listingResult[0];

    if (!listing) {
        throw new AppError(
            "Listing not found.",
            404,
            "LISTING_NOT_FOUND",
        );
    }

    if (listing.sellerId !== sellerId) {
        throw new AppError(
            "You do not have permission to submit this listing.",
            403,
            "LISTING_SUBMISSION_FORBIDDEN",
        );
    }

    // Enforce image eligibility at the API boundary as well as in the UI.
    // A seller must never be able to bypass the verification gate with a direct request.
    const imageRows = await db
        .select({
            id: listingImages.id,
            imageCheckStatus: listingImages.imageCheckStatus,
            checkReason: listingImages.checkReason,
        })
        .from(listingImages)
        .where(eq(listingImages.listingId, listingId));

    if (imageRows.length === 0) {
        throw new AppError(
            "Add at least one vehicle photo before submitting this listing.",
            409,
            "LISTING_IMAGES_REQUIRED",
        );
    }

    const pendingImages = imageRows.filter(
        (image) => image.imageCheckStatus === "PENDING",
    );
    if (pendingImages.length > 0) {
        throw new AppError(
            "Some photos are still being checked. Please wait for verification to finish.",
            409,
            "LISTING_IMAGE_CHECK_PENDING",
        );
    }

    const failedImages = imageRows.filter(
        (image) => image.imageCheckStatus === "FAILED",
    );
    if (failedImages.length > 0) {
        throw new AppError(
            "One or more photos failed verification. Replace the affected photos before submitting.",
            409,
            "LISTING_IMAGE_CHECK_FAILED",
            { images: failedImages.map((image) => ({ id: image.id, reason: image.checkReason })) },
        );
    }

    /*
     * Listing creation already consumed its credit.
     * Submission must not consume another credit.
     *
     * The centralized lifecycle service validates whether the listing can enter review.
     */
    const result = await transitionListing({
        listingId,
        action: "SUBMIT_FOR_REVIEW",
        actorId: sellerId,
    });

    // Persist notifications for administrators after the lifecycle transition.
    // Notification/email failures must not undo a valid listing submission.
    try {
        const reviewers = await db
            .selectDistinct({ id: users.id })
            .from(users)
            .innerJoin(userRoles, eq(userRoles.userId, users.id))
            .innerJoin(roles, eq(roles.id, userRoles.roleId))
            .where(inArray(roles.name, ["SUPER_ADMIN", "ADMIN"]));

        await Promise.allSettled(reviewers.map((reviewer) =>
            createNotification({
                userId: reviewer.id,
                type: "LISTING_SUBMITTED",
                title: "Listing ready for review",
                message: `Listing ${listingId} has been submitted for moderation. Open the admin listing review queue to inspect its details and image verification results.`,
                data: { listingId, event: "LISTING_SUBMITTED", submittedBy: sellerId },
                idempotencykey: `listing-submitted:${listingId}:admin:${reviewer.id}`,
            }),
        ));
    } catch (error) {
        logger.error({ err: error, listingId, sellerId }, "Listing submission succeeded, but administrator notifications could not be created.");
    }

    return result;
}

export async function restoreListing(
    listingId: string,
    sellerId: string,
) {
    const result =
        await db
            .select()
            .from(listings)
            .where(
                and(
                    eq(
                        listings.id,
                        listingId,
                    ),

                    eq(
                        listings.sellerId,
                        sellerId,
                    ),
                ),
            )
            .limit(1);

    const listing =
        result[0];

    if (!listing) {
        throw new Error(
            "Listing not found.",
        );
    }

    if (
        listing.status !==
        "DELETED"
    ) {
        throw new Error(
            "Only deleted listings can be restored.",
        );
    }

    return transitionListing({
        listingId,

        action:
            "RESTORE",

        actorId:
            sellerId,

        reason:
            "Listing restored by seller.",
    });
}

export async function markListingAsSold(
    listingId: string,
    sellerId: string,
) {
    const result =
        await db
            .select()
            .from(listings)
            .where(
                and(
                    eq(
                        listings.id,
                        listingId,
                    ),

                    eq(
                        listings.sellerId,
                        sellerId,
                    ),
                ),
            )
            .limit(1);

    const listing =
        result[0];

    if (!listing) {
        throw new Error(
            "Listing not found.",
        );
    }

    if (
        listing.status !==
        "APPROVED"
    ) {
        throw new Error(
            "Only approved listings can be marked as sold.",
        );
    }

    return transitionListing({
        listingId,

        action:
            "MARK_SOLD",

        actorId:
            sellerId,

        reason:
            "Listing marked as sold by seller.",
    });
}

export async function reactivateListing(
    listingId: string,
    sellerId: string,
) {
    const result = await db
        .select()
        .from(listings)
        .where(
            and(
                eq(listings.id, listingId),
                eq(listings.sellerId, sellerId),
            ),
        )
        .limit(1);

    const listing = result[0];

    if (!listing) {
        throw new AppError(
            "Listing not found or you do not have permission to reactivate it.",
            404,
            "LISTING_NOT_FOUND",
        );
    }

    switch (listing.status) {
        case "EXPIRED":
        case "SOLD":
        case "SUSPENDED":
            break;

        default:
            throw new AppError(
                "Only expired, sold, or suspended listings can be reactivated.",
                409,
                "LISTING_CANNOT_BE_REACTIVATED",
            );
    }

    return transitionListing({
        listingId,
        action: "REACTIVATE",
        actorId: sellerId,
        reason: "Listing reactivated by seller.",
    });
}

async function getListingCoverImages(
    listingIds: string[],
) {
    if (listingIds.length === 0) {
        return new Map<
            string,
            {
                id: string;
                objectKey: string;
                sortOrder: number;
                imageCheckStatus: string;
                thumbnailUrl: string;
                url: string;
            }
        >();
    }

    const images = await db
        .select({
            id: listingImages.id,
            listingId: listingImages.listingId,
            objectKey: listingImages.objectKey,
            sortOrder: listingImages.sortOrder,
            imageCheckStatus: listingImages.imageCheckStatus,
        })
        .from(listingImages)
        .where(
            and(
                sql`${listingImages.listingId} IN (${sql.join(
                    listingIds.map((id) => sql`${id}`),
                    sql`, `,
                )})`,
                eq(listingImages.imageCheckStatus, "PASSED"),
            ),
        )
        .orderBy(
            listingImages.sortOrder,
        );

    const storage = getObjectStorage();

    const coverImages = new Map<
        string,
        {
            id: string;
            objectKey: string;
            sortOrder: number;
            imageCheckStatus: string;
            thumbnailUrl: string;
            url: string;
        }
    >();

    for (const image of images) {
        if (coverImages.has(image.listingId)) {
            continue;
        }

        coverImages.set(
            image.listingId,
            {
                id: image.id,
                objectKey: image.objectKey,
                sortOrder: image.sortOrder,
                imageCheckStatus: image.imageCheckStatus,
                thumbnailUrl: storage.transformedImageUrl(
                    image.objectKey,
                    {
                        width: 600,
                        height: 600,
                        fit: "fit",
                        quality: "auto",
                        format: "webp",
                    },
                ),
                url: storage.publicUrl(
                    image.objectKey,
                    {
                        resourceType: "image",
                        access: "public",
                    },
                ),
            },
        );
    }

    return coverImages;
}

export async function getSellerListings(
    options: SellerListingsOptions,
) {
    const page = Math.max(
        options.page ?? 1,
        1,
    );

    const limit = Math.min(
        Math.max(
            options.limit ?? 20,
            1,
        ),
        100,
    );

    const offset = (page - 1) * limit;

    const conditions = [
        eq(
            listings.sellerId,
            options.sellerId,
        ),
    ];

    // Exclude deleted listings by default.
    // The Recently Deleted page can explicitly include them.
    if (!options.includeDeleted) {
        conditions.push(
            ne(
                listings.status,
                "DELETED",
            ),
        );
    }

    // Apply the requested status filter, if provided.
    if (options.status) {
        conditions.push(
            eq(
                listings.status,
                options.status,
            ),
        );
    }

    const rows = await db
        .select({
            listing: listings,
            vehicleVariant: vehicleVariants,
            vehicleGeneration: vehicleGenerations,
            vehicleModel: vehicleModels,
            vehicleMake: vehicleMakes,
        })
        .from(listings)
        .leftJoin(
            vehicleVariants,
            eq(
                listings.vehicleVariantId,
                vehicleVariants.id,
            ),
        )
        .leftJoin(
            vehicleGenerations,
            eq(
                vehicleVariants.generationId,
                vehicleGenerations.id,
            ),
        )
        .leftJoin(
            vehicleModels,
            eq(
                vehicleGenerations.modelId,
                vehicleModels.id,
            ),
        )
        .leftJoin(
            vehicleMakes,
            eq(
                vehicleModels.makeId,
                vehicleMakes.id,
            ),
        )
        .where(
            and(...conditions),
        )
        .orderBy(
            desc(listings.createdAt),
        )
        .limit(limit)
        .offset(offset);

    // Count records using the same conditions as the listings query.
    const totalResult = await db
        .select({
            count: count(),
        })
        .from(listings)
        .where(
            and(...conditions),
        );

    const total = Number(
        totalResult[0]?.count ?? 0,
    );

    const listingIds = rows.map(
        (row) => row.listing.id,
    );

    const [
        coverImages,
        imageSummaries,
    ] = await Promise.all([
        getListingCoverImages(listingIds),
        getSellerListingImageSummaries(listingIds),
    ]);

    const items = rows.map((row) => ({
        ...row,

        coverImage:
            coverImages.get(row.listing.id) ?? null,

        imageAnalysis:
            imageSummaries.get(row.listing.id) ?? {
                total: 0,
                pending: 0,
                passed: 0,
                review: 0,
                failed: 0,
                images: [],
            },
    }));

    return {
        items,

        pagination: {
            page,
            limit,
            total,

            totalPages: Math.ceil(
                total / limit,
            ),

            hasNextPage:
                page * limit < total,

            hasPreviousPage:
                page > 1,
        },
    };
}

export async function getSellerListingSummary(
    sellerId: string,
) {
    const rows = await db
        .select({
            status: listings.status,
            count: count(),
        })
        .from(listings)
        .where(
            eq(
                listings.sellerId,
                sellerId,
            ),
        )
        .groupBy(
            listings.status,
        );

    const summary: Record<
        SellerListingStatus,
        number
    > = {
        DRAFT: 0,
        PENDING_REVIEW: 0,
        APPROVED: 0,
        REJECTED: 0,
        EXPIRED: 0,
        SOLD: 0,
        SUSPENDED: 0,
        DELETED: 0,
    };

    for (const row of rows) {
        summary[row.status] = Number(
            row.count,
        );
    }

    // Count inventory without deleted listings.
    const total = Object.entries(
        summary,
    ).reduce(
        (sum, [status, value]) => {
            if (status === "DELETED") {
                return sum;
            }

            return sum + value;
        },
        0,
    );

    return {
        ...summary,

        // Total normal inventory.
        total,

        // Separate count for Recently Deleted.
        deleted: summary.DELETED,
    };
}

export async function retrySellerImageAnalysis(
    listingId: string,
    imageId: string,
    sellerId: string,
) {
    const [image] = await db
        .select({
            id: listingImages.id,
            listingId: listingImages.listingId,
        })
        .from(listingImages)
        .leftJoin(
            listings,
            eq(
                listingImages.listingId,
                listings.id,
            ),
        )
        .where(
            and(
                eq(listingImages.id, imageId),
                eq(listingImages.listingId, listingId),
                eq(listings.sellerId, sellerId),
            ),
        )
        .limit(1);

    if (!image) {
        throw new AppError(
            "Image not found or you do not have permission to retry its analysis.",
            404,
            "LISTING_IMAGE_NOT_FOUND",
        );
    }

    try {
        return await enqueueImageAnalysisJob({
            listingImageId: image.id,
            retryTechnicalFailure: true,
        });
    } catch (error) {
        const message =
            error instanceof Error
                ? error.message
                : "";

        if (
            message.includes("already passed review")
        ) {
            throw new AppError(
                "This image has already passed its checks.",
                409,
                "IMAGE_ALREADY_PASSED",
            );
        }

        if (
            message.includes("not identified as an automated-analysis failure")
        ) {
            throw new AppError(
                "This image cannot be retried automatically because its failure was not confirmed as an automated-analysis failure.",
                409,
                "IMAGE_RETRY_NOT_ALLOWED",
            );
        }

        if (
            message.includes("Only failed images")
        ) {
            throw new AppError(
                "Only failed images can be retried.",
                409,
                "IMAGE_NOT_ELIGIBLE_FOR_RETRY",
            );
        }

        if (
            message.includes("active image-analysis job already exists")
        ) {
            throw new AppError(
                "An analysis job already exists for this image. Please refresh and try again.",
                409,
                "IMAGE_ANALYSIS_ALREADY_ACTIVE",
            );
        }

        if (
            message.includes("not awaiting analysis")
        ) {
            throw new AppError(
                "This image is not eligible for retry.",
                409,
                "IMAGE_NOT_ELIGIBLE_FOR_RETRY",
            );
        }

        throw error;
    }
}
