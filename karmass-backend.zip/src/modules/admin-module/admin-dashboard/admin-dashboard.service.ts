import type { SQL } from "drizzle-orm";

import {
    and,
    eq,
    gte,
    inArray,
    sql,
} from "drizzle-orm";

import { db } from "../../../database/index.ts";

import {
    dealerApplications,
    listingBoosts,
    listingImages,
    listingReports,
    listings,
    payments,
    refundRequests,
    subscriptions,
    users,
} from "../../../database/schema/index.ts";

async function countFrom(
    table: any,
    where?: SQL<unknown>,
): Promise<number> {
    const rows = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(table)
        .where(where);

    return Number(rows[0]?.count ?? 0);
}

/**
 * Returns aggregate operational KPIs for the admin dashboard.
 * Revenue counts successful KARMASS payment records only; it does
 * not represent accounting profit or net revenue after refunds.
 */
export async function getAdminDashboard() {
    const monthStart = new Date();
    monthStart.setDate(1);
    monthStart.setHours(0, 0, 0, 0);

    const [
        totalUsers,
        activeUsers,
        suspendedUsers,
        totalListings,
        pendingListings,
        approvedListings,
        rejectedListings,
        suspendedListings,
        pendingDealers,
        activeSubscriptions,
        pendingBoosts,
        activeBoosts,
        pendingImageReviews,
        pendingReports,
        paymentTotals,
        monthlyRevenue,
        pendingRefunds,
    ] = await Promise.all([
        countFrom(users),
        countFrom(users, eq(users.status, "ACTIVE")),
        countFrom(users, eq(users.status, "SUSPENDED")),
        countFrom(listings),
        countFrom(listings, eq(listings.status, "PENDING_REVIEW")),
        countFrom(listings, eq(listings.status, "APPROVED")),
        countFrom(listings, eq(listings.status, "REJECTED")),
        countFrom(listings, eq(listings.status, "SUSPENDED")),
        countFrom(dealerApplications, eq(dealerApplications.status, "PENDING")),
        countFrom(subscriptions, eq(subscriptions.status, "ACTIVE")),
        countFrom(
            listingBoosts,
            inArray(listingBoosts.status, ["PENDING", "AWAITING_APPROVAL"]),
        ),
        countFrom(listingBoosts, eq(listingBoosts.status, "ACTIVE")),
        countFrom(
            listingImages,
            inArray(listingImages.imageCheckStatus, ["PENDING", "REVIEW"]),
        ),
        countFrom(listingReports, inArray(listingReports.status, ["PENDING", "REVIEWING"])),
        db.select({
            count: sql<number>`count(*)::int`,
            failedCount: sql<number>`count(*) filter (where ${payments.status} = 'FAILED')::int`,
        }).from(payments),
        db.select({
            currency: payments.currency,
            grossRevenue: sql<string>`coalesce(sum(${payments.amount}), 0)::text`,
        }).from(payments).where(
            and(
                eq(payments.status, "SUCCESS"),
                gte(payments.paidAt, monthStart),
            ),
        ).groupBy(payments.currency),
        countFrom(
            refundRequests,
            inArray(refundRequests.status, ["PENDING", "APPROVED", "PROCESSING"]),
        ),
    ]);

    const successfulPaymentRows = await db.select({
        currency: payments.currency,
        grossRevenue: sql<string>`coalesce(sum(${payments.amount}), 0)::text`,
        count: sql<number>`count(*)::int`,
    }).from(payments)
        .where(eq(payments.status, "SUCCESS"))
        .groupBy(payments.currency);

    return {
        generatedAt: new Date().toISOString(),
        users: {
            total: totalUsers,
            active: activeUsers,
            suspended: suspendedUsers,
        },
        listings: {
            total: totalListings,
            pending: pendingListings,
            approved: approvedListings,
            rejected: rejectedListings,
            suspended: suspendedListings,
        },
        dealers: {
            pendingApplications: pendingDealers,
        },
        subscriptions: {
            active: activeSubscriptions,
        },
        revenue: {
            successfulPaymentCount: successfulPaymentRows.reduce(
                (total, row) => total + Number(row.count ?? 0),
                0,
            ),
            grossSuccessfulPaymentsByCurrency: successfulPaymentRows.map((row) => ({
                currency: row.currency,
                amount: Number(row.grossRevenue ?? 0),
            })),
            grossSuccessfulPaymentsThisMonthByCurrency: monthlyRevenue.map((row) => ({
                currency: row.currency,
                amount: Number(row.grossRevenue ?? 0),
            })),
            note: "Gross successful payments before refunds, chargebacks, fees, and accounting adjustments. Amounts are not combined across currencies.",
        },
        payments: {
            total: Number(paymentTotals[0]?.count ?? 0),
            failed: Number(paymentTotals[0]?.failedCount ?? 0),
        },
        refunds: {
            pendingOrProcessing: pendingRefunds,
        },
        boosts: {
            pendingApproval: pendingBoosts,
            active: activeBoosts,
        },
        moderation: {
            pendingListings,
            pendingOrReviewImages: pendingImageReviews,
            pendingReports,
        },
    };
}

export async function getAdminSystemHealth() {
    const checkedAt = new Date().toISOString();
    let database: "healthy" | "unavailable" = "healthy";

    try {
        await db.execute(sql`SELECT 1`);
    } catch {
        database = "unavailable";
    }

    const memory = process.memoryUsage();

    return {
        status: database === "healthy" ? "healthy" : "degraded",
        checkedAt,
        uptimeSeconds: Math.floor(process.uptime()),
        environment: process.env.NODE_ENV ?? "development",
        database: {
            status: database,
        },
        runtime: {
            nodeVersion: process.version,
            memory: {
                rssBytes: memory.rss,
                heapUsedBytes: memory.heapUsed,
                heapTotalBytes: memory.heapTotal,
            },
        },
    };
}
