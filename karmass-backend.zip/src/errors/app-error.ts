export class AppError extends Error {
    public readonly statusCode: number;

    public readonly code: string;

    public readonly details?: unknown;

    public readonly isOperational: boolean;

    constructor(
        message: string,
        statusCode = 500,
        code = "INTERNAL_SERVER_ERROR",
        details?: unknown,
    ) {
        super(message);

        this.name = "AppError";

        this.statusCode =
            statusCode;

        this.code =
            code;

        this.details =
            details;

        this.isOperational =
            statusCode < 500;

        Error.captureStackTrace(
            this,
            AppError,
        );
    }
}